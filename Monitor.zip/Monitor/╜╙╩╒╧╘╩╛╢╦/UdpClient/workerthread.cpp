#include "workerthread.h"
#include "protocol.h"

extern  QMutex myMutex;
extern QSemaphore Sem;  //定义只含一个信号灯的信号量


WorkerThread::WorkerThread(QObject *parent) : QObject(parent)
{
    myClient = new QUdpSocket(this);   //资源由父对象this回收

    imgData_buf = new char[1024*1024];

    ReqCmd = new char[20];
    memcpy(ReqCmd,"Req",sizeof("Req"));   //构造请求帧

    ReqTimer = new QTimer(this);
    connect(ReqTimer,SIGNAL(timeout()),this,SLOT(doProcessSendReq()));   //定时发送请求信号槽

}

WorkerThread::~WorkerThread(){

    delete ReqCmd;
    delete imgData_buf;
}


//端口绑定
void WorkerThread::doProcessBindPort(QString ServerIP,QString ServerPort){

    s_ip = ServerIP;
    s_port = ServerPort.toInt();
//    if( !myClient->bind(s_port) )
//    {
//        qDebug() << "接收端口绑定失败！！！";
//        return;
//    }

//    #ifdef DEBUG_LOG
//        qDebug() << "接收端口绑定成功";
//    #endif
}

//开始采集
void WorkerThread::doProcessStartCapture(){

    //ReqTimer->start(1000.0/100);
    qint64 send_len = myClient->writeDatagram((const char*)ReqCmd,sizeof(ReqCmd),(const QHostAddress)s_ip,(quint16)s_port);
    if(send_len == -1){
        qDebug() << "请求帧发送失败！！！";
    }
    else{
        qDebug() << "请求帧发送成功！";
        qDebug("s_port: %d",s_port);
    }

    connect(myClient, SIGNAL(readyRead()), this, SLOT(doProcessRecvData()));    //数据接收触发槽

}

void WorkerThread::doProcessSendReq(){

//    qint64 send_len = myClient->writeDatagram((const char*)ReqCmd,sizeof(ReqCmd),(const QHostAddress)s_ip,(quint16)s_port);
//    if(send_len == -1){
//        qDebug() << "请求帧发送失败！！！";
//    }
//    else{
//        qDebug() << "请求帧发送成功！";
//    }
}

//停止采集
void WorkerThread::doProcessStopCapture(){

   // ReqTimer->stop(); //停止发送请求

    #ifdef DEBUG_LOG
        qDebug() << "停止采集";
    #endif
}

//图片接收【带protocol】
void WorkerThread::doProcessRecvData(){

    Sem.acquire(); //获取信号量

    //加锁,利用QMutexLocker管理会在该函数结束时自动析构解锁
   //QMutexLocker locker(&myMutex);
    myMutex.lock();  //加锁

    int recvSize = FRAME_SIZE + sizeof(struct ImageFrameHead);  //接收缓冲区大小
    char* revc_buf = new char[recvSize];  //图像数据接收缓冲区
    memset(revc_buf,0,recvSize);

    //接收数据
    while(myClient->hasPendingDatagrams())
    {
        memset(revc_buf,0,recvSize);
        int size =  myClient->pendingDatagramSize();  //取出当前数据报大小

        myClient->readDatagram(revc_buf,size );    //将数据读入接收缓存区
        struct ImageFrameHead* frameHead = (struct ImageFrameHead*)revc_buf;
        if(frameHead->funCode == 24){  //定位功能码位置
            memcpy(imgData_buf+frameHead->uDataInFrameOffset,revc_buf+sizeof(struct ImageFrameHead),frameHead->uTransFrameSize);  //取出图像数据
            if(frameHead->uDataFrameCurr == frameHead->uDataFrameTotal){
                emit SigRecvFinished(imgData_buf,frameHead->uDataFrameSize);  //发送接收完成信号
            }
        }


    }

    myMutex.unlock();  //解锁
    Sem.release();  //释放信号量

    delete revc_buf;

}
