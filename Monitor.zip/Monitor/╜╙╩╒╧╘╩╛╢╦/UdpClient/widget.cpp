#include "widget.h"
#include "ui_widget.h"
#include "workerthread.h"

QByteArray datagram;   //QByteArray用于存储图像数据报
QMutex myMutex;       //互斥锁
QSemaphore Sem(1);   //二值信号量

WorkerThread* workerObj = new WorkerThread;  //此处对象workerObj必须new出来，否则主线程信号无法传达到次线程中！原因未知

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
   // qRegisterMetaType<QByteArray>("QByteArray");

    show_timer = new QTimer(this);
    TimerFlag = false;

    Init();

    startObjthread();

}

Widget::~Widget()
{
    //等待次线程的结束
    worker.quit();
    worker.wait();
    delete ui;
}

/*===========================================function=============================================*/
void Widget::Init()
{
    //初始化按钮状态
    ui->Bt_StartCapture->setEnabled(false);
    ui->Bt_StopCapture->setEnabled(false);

    //默认服务器IP、端口
    ui->lineEdit_ServerIP->setText(QString("192.168.31.150"));
    ui->lineEdit_ServerPort->setText(QString("8889"));

    //获取IP、端口
    SeverPort = ui->lineEdit_ServerPort->text();
    ServerIP = ui->lineEdit_ServerIP->text();

    connect(show_timer,SIGNAL(timeout()),this,SLOT(update()));  //定时刷新屏幕,repaint（）立即刷新，update()下次循环才刷新

}

void Widget::startObjthread(){
    workerObj->moveToThread(&worker);            //将对象移动到线程

    //线程结束后自动销毁
    connect(&worker,SIGNAL(finished()),workerObj,SLOT(deleteLater()));


    connect(ui->Bt_BindPort,SIGNAL(clicked(bool)),this,SLOT(doProcessSendBindSig()));           //发送端口绑定信号槽
    connect(ui->Bt_StartCapture,SIGNAL(clicked(bool)),this,SLOT(doProcessSendStartSig()));      //发送开始采集信号槽
    connect(ui->Bt_StopCapture,SIGNAL(clicked(bool)),this,SLOT(doProcessSendStopSig()));        //发送停止采集信号槽

    connect(this,SIGNAL(SigToBindPort(QString,QString)),workerObj,SLOT(doProcessBindPort(QString,QString)));    //端口绑定信号槽
    connect(this,SIGNAL(SigToStartCapture()),workerObj,SLOT(doProcessStartCapture()));          //开始采集信号槽
    connect(workerObj,SIGNAL(SigRecvFinished(char*,int)),this,SLOT(doProcessShow(char*,int)));  //图像显示信号槽
    connect(this,SIGNAL(SigToStopCapture()),workerObj,SLOT(doProcessStopCapture()));            //停止采集信号槽

    //启动线程
    worker.start();
}

/*=========================================end function===========================================*/


/*=============================================slot===============================================*/

//绑定接收端口
void Widget::doProcessSendBindSig()
{
    //发送Port到次线程进行绑定
    emit SigToBindPort(ServerIP,SeverPort);
    ui->Bt_BindPort->setEnabled(false);
    ui->Bt_StartCapture->setEnabled(true);
}

//发送开始采集信号
void Widget::doProcessSendStartSig()
{
    emit SigToStartCapture();

    ui->Bt_StartCapture->setEnabled(false);
    ui->Bt_StopCapture->setEnabled(true);
}

//发送停止采集信号
void Widget::doProcessSendStopSig()
{
    emit SigToStopCapture();
    ui->Bt_StopCapture->setEnabled(false);
    ui->Bt_StartCapture->setEnabled(true);
}

//图片显示
void Widget::doProcessShow(char* imgData,int len){

    Sem.acquire(); //获取信号量

    //加锁
    //QMutexLocker locker(&myMutex);
    myMutex.lock();  //加锁

    //qDebug() << "图像数据长度: " << len << "   开始显示";

     //图片加载：方式一
     bool ret = img.loadFromData((uchar*)imgData,len,"JPG");
     if(!ret){  //加载失败
        // qDebug() << "loadFromData（）failed!";
         myMutex.unlock();  //解锁
         Sem.release(); //释放信号量
         return;
     }
     else{  //加载成功
         p_img = QPixmap::fromImage(img);  //转存入显示缓存区

         if(!p_img.isNull()){
             //开启定时显示
             if(!TimerFlag){
                 show_timer->start(1000.0/30);
                 TimerFlag = false;
             }
         }
         else {
             qDebug()<<"img is NULL";
         }
         myMutex.unlock();  //解锁
         Sem.release(); //释放信号量
     }
}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter mypainter(this);

    myMutex.lock();  //加锁
    //绘制图形
    mypainter.drawPixmap(0,0,640,480,p_img);

    myMutex.unlock();  //解锁

}


