#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QWidget>

#include <QMutex>
#include <QMutexLocker>

#include <QUdpSocket>
#include <QHostAddress>
#include <QSemaphore>

#include <QTimer>


#define FRAME_SIZE 1024

#define DEBUG_LOG

class WorkerThread : public QObject
{
    Q_OBJECT
public:
    explicit WorkerThread(QObject *parent = 0);
    ~WorkerThread();

signals:
    void SigRecvFinished(char*,int);

public slots:
    void doProcessBindPort(QString,QString);   //IP、端口绑定槽
    void doProcessStartCapture();      //开始采集槽
    void doProcessSendReq();           //定时请求槽
    void doProcessRecvData();          //数据接收槽
    void doProcessStopCapture();       //停止采集槽

private:
    QUdpSocket* myClient;

    QString s_ip; //服务器IP
    int s_port;   //服务器端口
    char* ReqCmd; //请求帧

    char* imgData_buf; //图像数据接收缓存区

    QTimer* ReqTimer;  //发送请求定时器

};

#endif // WORKERTHREAD_H
