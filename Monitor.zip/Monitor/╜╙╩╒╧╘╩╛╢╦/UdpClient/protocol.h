#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <iostream>


struct ImageFrameHead {
    int funCode;                        //功能码
    unsigned int uTransFrameHdrSize;    //头部大小
    unsigned int uTransFrameSize;       //单包传输大小（头部+图像数据）

    //数据帧变量
    unsigned int uDataFrameSize;        //图像数据帧的大小
    unsigned int uDataFrameTotal;       //一帧数据被分成传输帧的个数
    unsigned int uDataFrameCurr;        //数据帧当前的帧号
    unsigned int uDataInFrameOffset;    //数据帧在整帧的偏移
};

#endif // PROTOCOL_H
