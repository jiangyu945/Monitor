#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QUdpSocket>    //网络相关

#include <QImage>        //图片相关
#include <QPixmap>

#include <QPainter>      //画家

#include <QThread>       //多线程
#include <QByteArray>

#include <QMutex>        //互斥锁
#include <QMutexLocker>

#include <QSemaphore>    //信号量

#include <QBuffer>       //图片加载相关
#include <QImageReader>

#include <QTimer>        //定时器

#include <QDebug>        //调试打印

#define DEBUG_LOG      //启动调试输出

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

signals:
    void SigToBindPort(QString,QString);  //IP、端口绑定信号
    void SigToStartCapture();     //开始采集信号
    void SigToStopCapture();      //停止采集信号

private slots:
    void doProcessSendBindSig();        //发送绑定信号
    void doProcessSendStartSig();       //发送开始采集信号
    void doProcessShow(char*,int);      //数据显示槽
    void doProcessSendStopSig();        //发送停止采集信号

protected:
    virtual void paintEvent(QPaintEvent*);

private:
    Ui::Widget *ui;

    QString SeverPort;  //接收端口
    QString ServerIP;  //服务器IP

    QThread worker;
    QImage img;        //图像加载区
    QPixmap p_img;     //图像缓存区

    QTimer* show_timer; //显示定时器
    bool TimerFlag;    //显示定时器开启标志

    void Init();
    void startObjthread();
};

#endif // WIDGET_H
